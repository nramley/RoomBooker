const rooms = [

  {
    "name": "pasta",
    "id": "0987",
    "capacity": 5,
    "busy": true
  },

  {
    "name": "pizza",
    "id": "9876",
    "capacity": 5,
    "busy": false
  },

  {
    "name":"rice",
    "id": "8765",
    "capacity": 5,
    "busy": true
  },

  {
    "name": "curry",
    "id": "7654",
    "capacity": 5,
    "busy": false
  }
];

module.exports = rooms;
