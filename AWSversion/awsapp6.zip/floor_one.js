const rooms = [

  {
    "name": "pineapple",
    "id": "1234",
    "capacity": 5,
    "busy": true
  },

  {
    "name": "cake",
    "id": "2345",
    "capacity": 5,
    "busy": false
  },

  {
    "name":"biscuit",
    "id": "3456",
    "capacity": 5,
    "busy": true
  },

  {
    "name": "cupcake",
    "id": "4567",
    "capacity": 5,
    "busy": false
  },

  {
    "name": "cookie",
    "id": "5678",
    "capacity": 5,
    "busy": true
  },

  {
    "name": "pasta",
    "id": "6789",
    "capacity": 5,
    "busy": false
  }
];

module.exports = rooms;
